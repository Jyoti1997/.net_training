﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankLibrary
{
    public class Bank
    {
        
        //fields
        //methods

        private string accHolderName;
        private double balance;


        //property : getter() setter()
        //field name  - camelCase
        //propert - PascalCase

        public string AccHolderName
        {
            get { return accHolderName; }  //read
            set { accHolderName = value; }  //assignment
        }

        public double Balance
        {
            get { return balance; } 
            protected set { balance = value;  } //mixed access apecifier
            
        }

        public Bank()
        {
            balance = 1000;
        }

        public Bank(string name, double amount)
        {
            AccHolderName = name;
            Balance = amount;
        }

        public void Deposite(double amount)
        {
            balance += amount;
        }

        public virtual void Withdraw(double amount)
        {
            balance -= amount;
        }

        public override string ToString()
        {
            //traditional 
            //return "\nAccountHolderName = " + AccHolderName + "Balance =" + Balance;


            //placeHolder - formatedString
            //  return string.Format("AccountHolderName ={0} Balance = {1}", AccHolderName, Balance);

            // string interpolation
            return string.Format($"AccountHolderName ={AccHolderName} Balance = {Balance}");
        }
    }
}
