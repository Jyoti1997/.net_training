﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BankLibrary;

namespace DemoAppJLT
{
    internal class Program
    {
         static void Main(string[] args)
        {

            Savings savings = new Savings();
            Console.WriteLine(savings);

            Savings savings1 = new Savings("Amit", 30000);
            Console.WriteLine(savings1);
            try
            {
                savings1.Withdraw(50000);
            }
            catch (BalanceException ex)
            {
                Console.WriteLine(ex.Message);
            }
            Console.WriteLine(savings1);


          //  Console.WriteLine(DayOfWeek.Wednesday + ":" + (int)DayOfWeek.Wednesday);

            Console.ReadLine();
        }
        }
}
    







//    Bank bank = new Bank();
//    bank.AccHolderName = "Jyoti";
//    // bank.Balance = 10000;

//    Console.WriteLine(bank);

//    bank.Deposite(50000);
//    Console.WriteLine(bank);

//    bank.Withdraw(30000);
//    Console.WriteLine(bank);


//    Console.WriteLine("_______________________________________________");


//    Bank bank1 = new Bank("Akshay", 20000);
//    //Console.WriteLine("Account Holder Name =  " + bank1.AccHolderName + "\n Balance = " + bank1.Balance);
//    //or


//    //polymorphism - same signature give different behaviour

//    //Console.WriteLine(bank1);

//    //parent class reference pointing to child class object

//    Object obj = new Object();
//    Console.WriteLine(obj);

//    obj = bank1;
//    Console.WriteLine(obj);


//    Console.ReadLine();

    
//}
       